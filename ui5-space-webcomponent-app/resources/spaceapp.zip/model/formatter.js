"use strict";sap.ui.define([],function(){var r={formatValue:r=>{if(!r){return""}try{return parseFloat(r).toFixed(2)}catch(t){return r}}};return r});
//# sourceMappingURL=formatter.js.map